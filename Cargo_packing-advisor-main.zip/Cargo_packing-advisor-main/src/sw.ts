/// <reference lib="webworker" />
import { precacheAndRoute } from 'workbox-precaching'

declare let self: ServiceWorkerGlobalScope

precacheAndRoute(self.__WB_MANIFEST)

export const SHARE_CACHE = 'awb-share-cache'
export const SHARE_FILE_KEY = '/__shared-awb.pdf'

self.addEventListener('fetch', (event: FetchEvent) => {
  const url = new URL(event.request.url)

  // Web Share Target: WhatsApp -> Share -> Cargo Packing Advisor
  if (event.request.method === 'POST' && url.pathname === '/share-target') {
    event.respondWith(
      (async () => {
        try {
          const formData = await event.request.formData()
          const file = formData.get('file')
          if (file instanceof File) {
            const cache = await caches.open(SHARE_CACHE)
            await cache.put(
              SHARE_FILE_KEY,
              new Response(file, {
                headers: {
                  'Content-Type': file.type || 'application/pdf',
                  'X-File-Name': encodeURIComponent(file.name || 'shared.pdf'),
                },
              }),
            )
          }
        } catch {
          // fall through to redirect; app will show a recovery message
        }
        return Response.redirect('/?share-target=1', 303)
      })(),
    )
  }
})
