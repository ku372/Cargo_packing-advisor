export type CartonGroup = {
  length: number
  width: number
  height: number
  quantity: number
}

export type CargoFormValues = {
  material: string
  actualWeight: number
  cartonGroups: CartonGroup[]
  ratePerKg: number
}

export type FreightResult = {
  actualWeight: number
  totalVolumetricWeight: number
  chargeableWeight: number
  freightCost: number
  packingEfficiency: number
  extraFreightWeight: number
  extraFreightCost: number
  packingInefficient: boolean
}

export type EfficiencyTier = 'green' | 'yellow' | 'red'

export const DEFAULT_VOLUMETRIC_DIVISOR = 6000

/** Returns a finite, non-negative number; non-finite or negative inputs collapse to 0. */
function safeNumber(value: number): number {
  return Number.isFinite(value) && value > 0 ? value : 0
}

/** Rounds a weight up to the next 0.5 kg increment, as used on real air waybills. */
export function roundUpToHalfKg(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return 0
  return Math.ceil(value * 2) / 2
}

export function getEfficiencyTier(score: number): EfficiencyTier {
  if (score >= 90) return 'green'
  if (score >= 75) return 'yellow'
  return 'red'
}

export function calculatePackingEfficiency(actualWeight: number, chargeableWeight: number): number {
  if (chargeableWeight <= 0) return 0
  return (actualWeight / chargeableWeight) * 100
}

export function isPackingInefficient(
  actualWeight: number,
  totalVolumetricWeight: number,
): boolean {
  if (totalVolumetricWeight <= actualWeight) return false
  if (actualWeight <= 0) return true
  return totalVolumetricWeight > actualWeight * 1.1
}

export function calculateGroupVolumetricWeight(
  group: CartonGroup,
  divisor: number = DEFAULT_VOLUMETRIC_DIVISOR,
): number {
  const length = safeNumber(group.length)
  const width = safeNumber(group.width)
  const height = safeNumber(group.height)
  const quantity = safeNumber(group.quantity)
  const safeDivisor = Number.isFinite(divisor) && divisor > 0 ? divisor : DEFAULT_VOLUMETRIC_DIVISOR
  return (length * width * height * quantity) / safeDivisor
}

export function calculateFreight(
  values: CargoFormValues,
  divisor: number = DEFAULT_VOLUMETRIC_DIVISOR,
): FreightResult {
  const actualWeight = safeNumber(values.actualWeight)
  const ratePerKg = safeNumber(values.ratePerKg)
  const { cartonGroups } = values

  const totalVolumetricWeight = cartonGroups.reduce(
    (sum, group) => sum + calculateGroupVolumetricWeight(group, divisor),
    0,
  )
  // Round chargeable weight up to the next 0.5 kg, matching air waybill practice.
  const chargeableWeight = roundUpToHalfKg(Math.max(actualWeight, totalVolumetricWeight))
  const freightCost = chargeableWeight * ratePerKg
  const packingEfficiency = calculatePackingEfficiency(actualWeight, chargeableWeight)
  const extraFreightWeight = Math.max(chargeableWeight - actualWeight, 0)
  const extraFreightCost = extraFreightWeight * ratePerKg
  const packingInefficient = isPackingInefficient(actualWeight, totalVolumetricWeight)

  return {
    actualWeight,
    totalVolumetricWeight,
    chargeableWeight,
    freightCost,
    packingEfficiency,
    extraFreightWeight,
    extraFreightCost,
    packingInefficient,
  }
}
