import { describe, it, expect } from 'vitest'
import {
  calculateFreight,
  calculateGroupVolumetricWeight,
  calculatePackingEfficiency,
  getEfficiencyTier,
  isPackingInefficient,
  roundUpToHalfKg,
  type CargoFormValues,
} from './calculateFreight'

describe('roundUpToHalfKg', () => {
  it('rounds up to the next 0.5 kg', () => {
    expect(roundUpToHalfKg(10)).toBe(10)
    expect(roundUpToHalfKg(10.01)).toBe(10.5)
    expect(roundUpToHalfKg(10.5)).toBe(10.5)
    expect(roundUpToHalfKg(10.6)).toBe(11)
  })

  it('returns 0 for non-positive or non-finite values', () => {
    expect(roundUpToHalfKg(0)).toBe(0)
    expect(roundUpToHalfKg(-5)).toBe(0)
    expect(roundUpToHalfKg(Infinity)).toBe(0)
  })
})

describe('calculateGroupVolumetricWeight', () => {
  it('uses the /6000 divisor by default', () => {
    expect(calculateGroupVolumetricWeight({ length: 60, width: 50, height: 40, quantity: 1 })).toBe(
      (60 * 50 * 40) / 6000,
    )
  })

  it('supports a configurable divisor', () => {
    expect(
      calculateGroupVolumetricWeight({ length: 60, width: 50, height: 40, quantity: 1 }, 5000),
    ).toBe((60 * 50 * 40) / 5000)
  })

  it('treats non-finite dimensions as zero', () => {
    expect(
      calculateGroupVolumetricWeight({ length: NaN, width: 50, height: 40, quantity: 1 }),
    ).toBe(0)
  })
})

describe('getEfficiencyTier', () => {
  it('applies 90/75 thresholds', () => {
    expect(getEfficiencyTier(95)).toBe('green')
    expect(getEfficiencyTier(90)).toBe('green')
    expect(getEfficiencyTier(80)).toBe('yellow')
    expect(getEfficiencyTier(75)).toBe('yellow')
    expect(getEfficiencyTier(50)).toBe('red')
  })
})

describe('calculatePackingEfficiency', () => {
  it('returns 0 when chargeable weight is non-positive', () => {
    expect(calculatePackingEfficiency(10, 0)).toBe(0)
  })

  it('computes actual/chargeable percentage', () => {
    expect(calculatePackingEfficiency(50, 100)).toBe(50)
  })
})

describe('isPackingInefficient', () => {
  it('is false when volumetric <= actual', () => {
    expect(isPackingInefficient(100, 90)).toBe(false)
  })

  it('is true when volumetric exceeds actual by more than 10%', () => {
    expect(isPackingInefficient(100, 120)).toBe(true)
    expect(isPackingInefficient(100, 105)).toBe(false)
  })
})

describe('calculateFreight', () => {
  const base: CargoFormValues = {
    material: 'General Cargo',
    actualWeight: 100,
    ratePerKg: 50,
    cartonGroups: [{ length: 60, width: 50, height: 40, quantity: 1 }],
  }

  it('uses actual weight when it exceeds volumetric (rounded to 0.5 kg)', () => {
    const r = calculateFreight(base)
    // volumetric = 120000/6000 = 20; actual 100 dominates; 100 already on 0.5 grid
    expect(r.totalVolumetricWeight).toBe(20)
    expect(r.chargeableWeight).toBe(100)
    expect(r.freightCost).toBe(5000)
    expect(r.extraFreightWeight).toBe(0)
  })

  it('rounds chargeable weight up to the next 0.5 kg when volumetric dominates', () => {
    const r = calculateFreight({
      ...base,
      actualWeight: 10,
      cartonGroups: [{ length: 61, width: 50, height: 40, quantity: 1 }],
    })
    // volumetric = 122000/6000 = 20.333... -> rounds up to 20.5
    expect(r.chargeableWeight).toBe(20.5)
    expect(r.freightCost).toBe(20.5 * 50)
    expect(r.extraFreightWeight).toBe(20.5 - 10)
  })

  it('never produces Infinity for non-finite inputs', () => {
    const r = calculateFreight({
      ...base,
      actualWeight: Number.POSITIVE_INFINITY,
      ratePerKg: Number.NaN,
    })
    expect(Number.isFinite(r.freightCost)).toBe(true)
    expect(Number.isFinite(r.chargeableWeight)).toBe(true)
  })
})
