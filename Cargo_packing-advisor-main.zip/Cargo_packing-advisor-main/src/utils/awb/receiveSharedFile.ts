// Reads a PDF delivered via the Web Share Target API.
// The service worker (src/sw.ts) stores the shared file in Cache Storage and
// redirects to /?share-target=1. This util retrieves and clears it.

const SHARE_CACHE = 'awb-share-cache'
const SHARE_FILE_KEY = '/__shared-awb.pdf'

export function hasSharedFileFlag(): boolean {
  if (typeof window === 'undefined') return false
  return new URLSearchParams(window.location.search).get('share-target') === '1'
}

export function clearShareFlagFromUrl(): void {
  if (typeof window === 'undefined' || !window.history?.replaceState) return
  const url = new URL(window.location.href)
  url.searchParams.delete('share-target')
  window.history.replaceState({}, '', url.pathname + url.search + url.hash)
}

/** Returns the shared PDF File if present, then removes it from the cache. */
export async function receiveSharedFile(): Promise<File | null> {
  if (typeof caches === 'undefined') return null
  try {
    const cache = await caches.open(SHARE_CACHE)
    const response = await cache.match(SHARE_FILE_KEY)
    if (!response) return null

    const blob = await response.blob()
    const encodedName = response.headers.get('X-File-Name')
    const name = encodedName ? decodeURIComponent(encodedName) : 'shared-awb.pdf'
    await cache.delete(SHARE_FILE_KEY)

    return new File([blob], name, { type: blob.type || 'application/pdf' })
  } catch {
    return null
  }
}
