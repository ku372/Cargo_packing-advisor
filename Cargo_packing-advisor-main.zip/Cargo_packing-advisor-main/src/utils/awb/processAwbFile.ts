import { extractPdfText, AwbPdfError } from './extractPdfText'
import { parseAwbFields } from './parseAwbFields'
import type { AwbExtractionResult } from './types'

export type ProcessAwbOutcome =
  | { status: 'ok'; result: AwbExtractionResult; file: File }
  | { status: 'error'; message: string }

/**
 * Single processing path used by both manual upload and the Web Share Target
 * flow: validate the PDF, extract text, detect scanned PDFs, and parse fields.
 * Never throws — returns a discriminated outcome.
 */
export async function processAwbFile(file: File): Promise<ProcessAwbOutcome> {
  try {
    const { text, hasText } = await extractPdfText(file)
    if (!hasText) {
      return {
        status: 'error',
        message:
          'No readable text found. This looks like a scanned PDF — enter values manually.',
      }
    }
    const result = parseAwbFields(text)
    if (result.status === 'failed') {
      return {
        status: 'error',
        message: 'Could not detect AWB fields in this PDF. Please enter values manually.',
      }
    }
    return { status: 'ok', result, file }
  } catch (err) {
    if (err instanceof AwbPdfError) return { status: 'error', message: err.message }
    return { status: 'error', message: 'Failed to read the PDF. Please try another file.' }
  }
}
