import type {
  AwbExtractionResult,
  FieldConfidence,
  ParsedCartonGroup,
} from './types'

const LB_TO_KG = 0.45359237

function fc(value: string, confidence: number): FieldConfidence<string> {
  return { value, confidence }
}

function normalizeNumber(raw: string): string | null {
  const cleaned = raw.replace(/,/g, '').trim()
  const num = Number(cleaned)
  if (!Number.isFinite(num) || num <= 0) return null
  return String(num)
}

function toKg(raw: string, unit: string): string | null {
  const cleaned = raw.replace(/,/g, '').trim()
  const num = Number(cleaned)
  if (!Number.isFinite(num) || num <= 0) return null
  const isLb = /^(lbs?|pounds?)$/i.test(unit)
  const kg = isLb ? num * LB_TO_KG : num
  return (Math.round(kg * 100) / 100).toString()
}

const WEIGHT_UNIT = '(kgs?|kg|lbs?|lb|pounds?)?'

const GROSS_WEIGHT_PATTERNS: { re: RegExp; confidence: number }[] = [
  { re: new RegExp(`gross\\s*weight\\s*[:\\-]?\\s*([\\d.,]+)\\s*${WEIGHT_UNIT}`, 'i'), confidence: 0.9 },
  { re: new RegExp(`actual\\s*weight\\s*[:\\-]?\\s*([\\d.,]+)\\s*${WEIGHT_UNIT}`, 'i'), confidence: 0.88 },
  { re: new RegExp(`gross\\s*wt\\.?\\s*[:\\-]?\\s*([\\d.,]+)\\s*${WEIGHT_UNIT}`, 'i'), confidence: 0.8 },
  { re: new RegExp(`\\bg\\.?\\s*w\\.?\\s*[:\\-]?\\s*([\\d.,]+)\\s*${WEIGHT_UNIT}`, 'i'), confidence: 0.6 },
]

const CHARGEABLE_PATTERNS: { re: RegExp; confidence: number }[] = [
  { re: /chargeable\s*weight\s*[:\-]?\s*([\d.,]+)/i, confidence: 0.85 },
  { re: /chg\.?\s*wt\.?\s*[:\-]?\s*([\d.,]+)/i, confidence: 0.7 },
]

// AWB numbers are commonly 3-digit prefix + 8 digits, optionally with a dash.
const AWB_PATTERNS: { re: RegExp; confidence: number }[] = [
  { re: /(?:awb|air\s*waybill)\s*(?:no\.?|number|#)?\s*[:\-]?\s*(\d{3}[-\s]?\d{8})/i, confidence: 0.9 },
  { re: /\b(\d{3}-\d{8})\b/, confidence: 0.7 },
]

const ORIGIN_PATTERNS: { re: RegExp; confidence: number }[] = [
  { re: /(?:origin|airport\s*of\s*departure|from)\s*[:\-]?\s*([A-Z]{3})\b/i, confidence: 0.85 },
]

const DESTINATION_PATTERNS: { re: RegExp; confidence: number }[] = [
  { re: /(?:destination|airport\s*of\s*destination|to)\s*[:\-]?\s*([A-Z]{3})\b/i, confidence: 0.85 },
]

const PIECES_PATTERNS: { re: RegExp; confidence: number }[] = [
  { re: /(?:no\.?\s*of\s*pieces|pieces|pcs|pkgs?|packages?)\s*[:\-]?\s*(\d{1,5})\b/i, confidence: 0.8 },
]

const COMMODITY_PATTERNS: { re: RegExp; confidence: number }[] = [
  { re: /(?:commodity|nature\s*(?:and|&)\s*quantity\s*of\s*goods|goods\s*description)\s*[:\-]?\s*([A-Za-z][A-Za-z \-/]{2,40})/i, confidence: 0.7 },
]

// L x W x H with optional trailing quantity. Separators: x X * ×
const DIMENSION_RE =
  /(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)\s*[x×*]\s*(\d+(?:\.\d+)?)(?:\s*(?:[x×*]|@)\s*(\d+)(?:\s*(?:pcs?|pieces?))?|\s+(\d+)\s*(?:pcs?|pieces?))?/gi

function matchFirst(
  text: string,
  patterns: { re: RegExp; confidence: number }[],
): FieldConfidence<string> | null {
  for (const { re, confidence } of patterns) {
    const m = text.match(re)
    if (m && m[1]) return fc(m[1].trim(), confidence)
  }
  return null
}

function extractGrossWeight(text: string): {
  field: FieldConfidence<string> | null
  converted: boolean
} {
  for (const { re, confidence } of GROSS_WEIGHT_PATTERNS) {
    const m = text.match(re)
    if (m && m[1]) {
      const unit = (m[2] ?? '').toLowerCase()
      const value = toKg(m[1], unit)
      if (value) return { field: fc(value, confidence), converted: /^(lbs?|pounds?)$/i.test(unit) }
    }
  }
  return { field: null, converted: false }
}

function extractChargeable(text: string): FieldConfidence<string> | null {
  for (const { re, confidence } of CHARGEABLE_PATTERNS) {
    const m = text.match(re)
    if (m && m[1]) {
      const value = normalizeNumber(m[1])
      if (value) return fc(value, confidence)
    }
  }
  return null
}

function extractDimensions(text: string): ParsedCartonGroup[] {
  const groups: ParsedCartonGroup[] = []
  let match: RegExpExecArray | null
  DIMENSION_RE.lastIndex = 0
  while ((match = DIMENSION_RE.exec(text)) !== null) {
    const [, l, w, h, qtyA, qtyB] = match
    const length = normalizeNumber(l)
    const width = normalizeNumber(w)
    const height = normalizeNumber(h)
    const quantity = normalizeNumber(qtyA ?? qtyB ?? '1') ?? '1'
    if (length && width && height) groups.push({ length, width, height, quantity })
  }
  return groups
}

function normalizePieces(field: FieldConfidence<string> | null): FieldConfidence<string> | null {
  if (!field) return null
  const value = normalizeNumber(field.value)
  return value ? fc(value, field.confidence) : null
}

/**
 * Pure, deterministic AWB text parser. Input is already-extracted plain text
 * (no pdf.js, no OCR, no file I/O). Never throws.
 */
export function parseAwbFields(rawText: string): AwbExtractionResult {
  const text = rawText ?? ''
  const warnings: string[] = []

  const { field: grossWeight, converted } = extractGrossWeight(text)
  const chargeableWeight = extractChargeable(text)
  const awbNumber = matchFirst(text, AWB_PATTERNS)
  const origin = matchFirst(text, ORIGIN_PATTERNS)
  const destination = matchFirst(text, DESTINATION_PATTERNS)
  const pieces = normalizePieces(matchFirst(text, PIECES_PATTERNS))
  const commodity = matchFirst(text, COMMODITY_PATTERNS)
  const cartonGroups = extractDimensions(text)

  if (!grossWeight) warnings.push('Gross weight not detected')
  if (converted) warnings.push('Weight converted from lb to kg')
  if (cartonGroups.length === 0) warnings.push('No carton dimensions detected')
  if (!awbNumber) warnings.push('AWB number not detected')

  const hasWeight = grossWeight !== null
  const hasDims = cartonGroups.length > 0

  let status: AwbExtractionResult['status']
  if (hasWeight && hasDims) status = 'ok'
  else if (hasWeight || hasDims || awbNumber) status = 'partial'
  else status = 'failed'

  return {
    status,
    awbNumber,
    origin,
    destination,
    pieces,
    grossWeight,
    chargeableWeight,
    commodity,
    cartonGroups,
    warnings,
  }
}
