import { describe, it, expect } from 'vitest'
import { parseAwbFields } from './parseAwbFields'
import { confidenceTier } from './types'

describe('parseAwbFields', () => {
  it('extracts gross weight in kg as a string', () => {
    const r = parseAwbFields('Gross Weight: 125.5 kg')
    expect(r.grossWeight?.value).toBe('125.5')
    expect(typeof r.grossWeight?.value).toBe('string')
  })

  it('converts lb to kg and warns', () => {
    const r = parseAwbFields('Gross Weight: 100 lb')
    expect(r.grossWeight?.value).toBe('45.36')
    expect(r.warnings).toContain('Weight converted from lb to kg')
  })

  it('strips thousands separators', () => {
    const r = parseAwbFields('Gross Weight: 1,250 kg')
    expect(r.grossWeight?.value).toBe('1250')
  })

  it('extracts AWB number, origin, destination, pieces, commodity', () => {
    const text =
      'AWB No: 125-12345678 Origin: BOM Destination: DXB No. of Pieces: 12 Commodity: Fresh Flowers Gross Weight: 300 kg 40 x 30 x 25 x 12'
    const r = parseAwbFields(text)
    expect(r.awbNumber?.value).toBe('125-12345678')
    expect(r.origin?.value).toBe('BOM')
    expect(r.destination?.value).toBe('DXB')
    expect(r.pieces?.value).toBe('12')
    expect(r.commodity?.value.toLowerCase()).toContain('flowers')
  })

  it('parses single and multiple dimension groups, quantity defaults to 1', () => {
    const single = parseAwbFields('Gross Weight: 50 kg 40 x 30 x 25')
    expect(single.cartonGroups).toEqual([{ length: '40', width: '30', height: '25', quantity: '1' }])

    const multi = parseAwbFields('40x30x25 x 6\n20*15*10 @ 3 pcs\nGross Weight: 200 kg')
    expect(multi.cartonGroups).toHaveLength(2)
    expect(multi.cartonGroups[0].quantity).toBe('6')
    expect(multi.cartonGroups[1].quantity).toBe('3')
  })

  it('supports x, X, * and × separators', () => {
    expect(parseAwbFields('10x20x30').cartonGroups[0].height).toBe('30')
    expect(parseAwbFields('10X20X30').cartonGroups[0].height).toBe('30')
    expect(parseAwbFields('10*20*30').cartonGroups[0].height).toBe('30')
    expect(parseAwbFields('10×20×30').cartonGroups[0].height).toBe('30')
  })

  it('captures chargeable weight separately and never as gross', () => {
    const r = parseAwbFields('Chargeable Weight: 300 kg 50 x 40 x 30')
    expect(r.chargeableWeight?.value).toBe('300')
    expect(r.grossWeight).toBeNull()
    expect(r.status).toBe('partial')
  })

  it('returns failed with warnings when nothing recognizable', () => {
    const r = parseAwbFields('Flight AB123 Carrier XYZ')
    expect(r.status).toBe('failed')
    expect(r.grossWeight).toBeNull()
    expect(r.cartonGroups).toHaveLength(0)
    expect(r.warnings.length).toBeGreaterThan(0)
  })

  it('returns ok when both weight and dimensions present', () => {
    const r = parseAwbFields('Gross Weight: 60 kg 40 x 30 x 20 x 4')
    expect(r.status).toBe('ok')
    expect(r.cartonGroups[0].quantity).toBe('4')
  })

  it('does not throw on empty input', () => {
    expect(() => parseAwbFields('')).not.toThrow()
    expect(parseAwbFields('').status).toBe('failed')
  })
})

describe('confidenceTier', () => {
  it('maps scores to high/medium/low', () => {
    expect(confidenceTier(0.9)).toBe('high')
    expect(confidenceTier(0.6)).toBe('medium')
    expect(confidenceTier(0.3)).toBe('low')
  })
})
