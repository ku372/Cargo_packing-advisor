import * as pdfjsLib from 'pdfjs-dist'
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url'

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker

export type AwbPdfErrorCode = 'invalid' | 'empty' | 'unsupported' | 'too_large' | 'parse_failed'

export class AwbPdfError extends Error {
  code: AwbPdfErrorCode
  constructor(code: AwbPdfErrorCode, message: string) {
    super(message)
    this.name = 'AwbPdfError'
    this.code = code
  }
}

export const MAX_PDF_BYTES = 10 * 1024 * 1024 // 10 MB
export const MAX_PDF_PAGES = 10

function hasPdfMagicBytes(bytes: Uint8Array): boolean {
  // %PDF
  return bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46
}

/** Validates a File is a usable PDF before parsing. Throws AwbPdfError on failure. */
export async function validatePdfFile(file: File): Promise<Uint8Array> {
  if (file.type && file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
    throw new AwbPdfError('unsupported', 'Unsupported file format. Please upload a PDF.')
  }
  if (file.size === 0) {
    throw new AwbPdfError('empty', 'The file is empty.')
  }
  if (file.size > MAX_PDF_BYTES) {
    throw new AwbPdfError('too_large', 'File is too large. Maximum size is 10 MB.')
  }
  const bytes = new Uint8Array(await file.arrayBuffer())
  if (bytes.length < 5 || !hasPdfMagicBytes(bytes)) {
    throw new AwbPdfError('invalid', 'The file is not a valid PDF.')
  }
  return bytes
}

export type PdfExtractionResult = {
  text: string
  pageCount: number
  hasText: boolean
}

/** Extracts text from a digital (text-based) PDF using pdf.js. */
export async function extractPdfText(file: File): Promise<PdfExtractionResult> {
  const bytes = await validatePdfFile(file)

  let doc
  try {
    doc = await pdfjsLib.getDocument({ data: bytes }).promise
  } catch {
    throw new AwbPdfError('parse_failed', 'Could not read the PDF. It may be corrupted or encrypted.')
  }

  if (doc.numPages === 0) {
    throw new AwbPdfError('empty', 'The PDF has no pages.')
  }

  const pageCount = Math.min(doc.numPages, MAX_PDF_PAGES)
  const parts: string[] = []

  for (let pageNum = 1; pageNum <= pageCount; pageNum++) {
    const page = await doc.getPage(pageNum)
    const content = await page.getTextContent()
    const pageText = content.items
      .map((item) => ('str' in item ? item.str : ''))
      .join(' ')
    parts.push(pageText)
  }

  const text = parts.join('\n').replace(/\s+/g, ' ').trim()
  return { text, pageCount, hasText: text.length >= 20 }
}
