// AWB parser data contract. All values returned to the form layer are STRINGS,
// because the calculator form state stores weight and dimensions as strings.

export type ConfidenceTier = 'high' | 'medium' | 'low'

export type FieldConfidence<T> = {
  value: T
  confidence: number // 0..1
}

// Matches the shape consumed by setCartonGroups (IDs assigned by the UI layer).
export type ParsedCartonGroup = {
  length: string
  width: string
  height: string
  quantity: string
}

export type AwbExtractionStatus = 'ok' | 'partial' | 'failed'

export type AwbExtractionResult = {
  status: AwbExtractionStatus
  awbNumber: FieldConfidence<string> | null
  origin: FieldConfidence<string> | null
  destination: FieldConfidence<string> | null
  pieces: FieldConfidence<string> | null
  grossWeight: FieldConfidence<string> | null // maps to actual weight
  chargeableWeight: FieldConfidence<string> | null // reference only
  commodity: FieldConfidence<string> | null
  cartonGroups: ParsedCartonGroup[]
  warnings: string[]
}

export function confidenceTier(confidence: number): ConfidenceTier {
  if (confidence >= 0.8) return 'high'
  if (confidence >= 0.5) return 'medium'
  return 'low'
}

/** Overall confidence is the minimum of the populated key fields. */
export function overallConfidence(result: AwbExtractionResult): number {
  const fields = [
    result.grossWeight,
    result.awbNumber,
    result.origin,
    result.destination,
    result.pieces,
  ].filter((f): f is FieldConfidence<string> => f !== null)
  if (fields.length === 0) return 0
  return Math.min(...fields.map((f) => f.confidence))
}
