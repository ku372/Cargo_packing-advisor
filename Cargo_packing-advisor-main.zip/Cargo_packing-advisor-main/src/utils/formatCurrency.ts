export function formatCurrency(
  value: number,
  locale: string = 'en-IN',
  currency: string = 'INR',
): string {
  const safeValue = Number.isFinite(value) ? value : 0
  return safeValue.toLocaleString(locale, {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })
}
