import { describe, it, expect } from 'vitest'
import { formatCurrency } from './formatCurrency'

describe('formatCurrency', () => {
  it('formats INR with the Rupee symbol by default', () => {
    expect(formatCurrency(1234.5)).toContain('\u20b9')
  })

  it('handles non-finite values gracefully', () => {
    expect(formatCurrency(Number.NaN)).toContain('\u20b9')
    expect(formatCurrency(Number.POSITIVE_INFINITY)).toContain('\u20b9')
  })

  it('supports overriding locale and currency', () => {
    const usd = formatCurrency(1000, 'en-US', 'USD')
    expect(usd).toContain('$')
  })
})
