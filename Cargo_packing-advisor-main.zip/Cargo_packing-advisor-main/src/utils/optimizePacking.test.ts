import { describe, it, expect } from 'vitest'
import { optimizePacking } from './optimizePacking'
import type { CargoFormValues } from './calculateFreight'

describe('optimizePacking', () => {
  it('reports no change when actual weight dominates', () => {
    const values: CargoFormValues = {
      material: 'General Cargo',
      actualWeight: 1000,
      ratePerKg: 50,
      cartonGroups: [{ length: 60, width: 50, height: 40, quantity: 1 }],
    }
    const r = optimizePacking(values)
    expect(r.weightSaved).toBe(0)
    expect(r.recommendedOption).toMatch(/No change needed/)
  })

  it('finds a height reduction when volumetric dominates', () => {
    const values: CargoFormValues = {
      material: 'General Cargo',
      actualWeight: 1,
      ratePerKg: 50,
      cartonGroups: [{ length: 100, width: 100, height: 50, quantity: 1 }],
    }
    const r = optimizePacking(values)
    expect(r.weightSaved).toBeGreaterThanOrEqual(0)
    expect(Number.isFinite(r.freightSaving)).toBe(true)
  })

  it('does not throw on non-finite rate', () => {
    const values: CargoFormValues = {
      material: 'General Cargo',
      actualWeight: 1,
      ratePerKg: Number.NaN,
      cartonGroups: [{ length: 100, width: 100, height: 50, quantity: 1 }],
    }
    expect(() => optimizePacking(values)).not.toThrow()
    expect(Number.isFinite(optimizePacking(values).freightSaving)).toBe(true)
  })
})
