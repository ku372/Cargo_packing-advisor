import { useMemo, useState } from 'react'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import Card from '@mui/material/Card'
import CardContent from '@mui/material/CardContent'
import Checkbox from '@mui/material/Checkbox'
import Chip from '@mui/material/Chip'
import FormControlLabel from '@mui/material/FormControlLabel'
import Grid from '@mui/material/Grid'
import Typography from '@mui/material/Typography'
import FactCheckIcon from '@mui/icons-material/FactCheck'
import {
  confidenceTier,
  overallConfidence,
  type AwbExtractionResult,
  type ConfidenceTier,
  type FieldConfidence,
} from '../../utils/awb/types'

type AwbReviewCardProps = {
  result: AwbExtractionResult
  onApply: () => void
  onDiscard: () => void
}

const tierColor: Record<ConfidenceTier, 'success' | 'warning' | 'error'> = {
  high: 'success',
  medium: 'warning',
  low: 'error',
}

const tierLabel: Record<ConfidenceTier, string> = {
  high: 'High',
  medium: 'Medium',
  low: 'Low',
}

function Field({ label, field }: { label: string; field: FieldConfidence<string> | null }) {
  if (!field) {
    return (
      <Grid size={{ xs: 12, sm: 6 }}>
        <Typography variant="body2" color="text.secondary">
          {label}
        </Typography>
        <Typography variant="body2" sx={{ fontStyle: 'italic', color: 'text.disabled' }}>
          Not detected
        </Typography>
      </Grid>
    )
  }
  const tier = confidenceTier(field.confidence)
  return (
    <Grid size={{ xs: 12, sm: 6 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 1 }}>
        <Typography variant="body2" color="text.secondary">
          {label}
        </Typography>
        <Chip size="small" color={tierColor[tier]} label={tierLabel[tier]} />
      </Box>
      <Typography variant="subtitle1" sx={{ fontWeight: 600, overflowWrap: 'anywhere' }}>
        {field.value}
      </Typography>
    </Grid>
  )
}

export default function AwbReviewCard({ result, onApply, onDiscard }: AwbReviewCardProps) {
  const tier = useMemo(() => confidenceTier(overallConfidence(result)), [result])
  const requiresConfirm = tier === 'low'
  const [confirmed, setConfirmed] = useState(false)

  const dims =
    result.cartonGroups.length > 0
      ? result.cartonGroups
          .map((g) => `${g.length}×${g.width}×${g.height} (x${g.quantity})`)
          .join(', ')
      : null

  return (
    <Card variant="outlined" sx={{ mb: 3, borderColor: 'primary.main' }}>
      <CardContent sx={{ p: { xs: 2, sm: 2.5 } }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
          <FactCheckIcon color="primary" />
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Review extracted AWB data
          </Typography>
          <Chip
            size="small"
            color={tierColor[tier]}
            label={`Overall: ${tierLabel[tier]}`}
            sx={{ ml: 'auto' }}
          />
        </Box>

        <Grid container spacing={2}>
          <Field label="AWB Number" field={result.awbNumber} />
          <Field label="Commodity" field={result.commodity} />
          <Field label="Origin" field={result.origin} />
          <Field label="Destination" field={result.destination} />
          <Field label="Pieces" field={result.pieces} />
          <Field label="Gross Weight (kg)" field={result.grossWeight} />
          <Field label="Chargeable Weight (kg)" field={result.chargeableWeight} />
          <Grid size={{ xs: 12, sm: 6 }}>
            <Typography variant="body2" color="text.secondary">
              Dimensions (cm)
            </Typography>
            <Typography variant="subtitle1" sx={{ fontWeight: 600, overflowWrap: 'anywhere' }}>
              {dims ?? 'Not detected'}
            </Typography>
          </Grid>
        </Grid>

        {result.warnings.length > 0 && (
          <Box sx={{ mt: 2 }}>
            {result.warnings.map((w) => (
              <Typography key={w} variant="caption" color="text.secondary" display="block">
                • {w}
              </Typography>
            ))}
          </Box>
        )}

        {requiresConfirm && (
          <FormControlLabel
            sx={{ mt: 1.5 }}
            control={
              <Checkbox
                checked={confirmed}
                onChange={(e) => setConfirmed(e.target.checked)}
              />
            }
            label="Confidence is low. I have reviewed these values and confirm they are correct."
          />
        )}

        <Box sx={{ display: 'flex', gap: 2, mt: 2, flexWrap: 'wrap' }}>
          <Button
            variant="contained"
            onClick={onApply}
            disabled={requiresConfirm && !confirmed}
            sx={{ flexGrow: 1 }}
          >
            Apply to calculator
          </Button>
          <Button variant="outlined" color="inherit" onClick={onDiscard}>
            Discard
          </Button>
        </Box>
      </CardContent>
    </Card>
  )
}
