import { useRef, useState, type DragEvent } from 'react'
import Box from '@mui/material/Box'
import Button from '@mui/material/Button'
import CircularProgress from '@mui/material/CircularProgress'
import Typography from '@mui/material/Typography'
import Alert from '@mui/material/Alert'
import UploadFileIcon from '@mui/icons-material/UploadFile'
import { processAwbFile } from '../../utils/awb/processAwbFile'
import type { AwbExtractionResult } from '../../utils/awb/types'

type AwbUploadProps = {
  onExtracted: (result: AwbExtractionResult, file: File) => void
}

export default function AwbUpload({ onExtracted }: AwbUploadProps) {
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [dragOver, setDragOver] = useState(false)

  const handleFile = async (file: File) => {
    setError(null)
    setLoading(true)
    const outcome = await processAwbFile(file)
    setLoading(false)
    if (outcome.status === 'ok') onExtracted(outcome.result, outcome.file)
    else setError(outcome.message)
  }

  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files?.[0]
    if (file) void handleFile(file)
  }

  return (
    <Box sx={{ mb: 3 }}>
      <Box
        role="button"
        tabIndex={0}
        onClick={() => inputRef.current?.click()}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') inputRef.current?.click()
        }}
        onDragOver={(e) => {
          e.preventDefault()
          setDragOver(true)
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        sx={{
          border: '2px dashed',
          borderColor: dragOver ? 'primary.main' : 'divider',
          bgcolor: dragOver ? 'rgba(21, 101, 192, 0.06)' : 'background.paper',
          borderRadius: 2,
          p: { xs: 3, sm: 4 },
          textAlign: 'center',
          cursor: 'pointer',
          transition: 'border-color 0.2s ease, background-color 0.2s ease',
        }}
      >
        {loading ? (
          <CircularProgress size={28} />
        ) : (
          <UploadFileIcon sx={{ fontSize: 40, color: 'primary.main', mb: 1 }} />
        )}
        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
          {loading ? 'Reading PDF…' : 'Upload AWB PDF'}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Drag &amp; drop a PDF here, or click to browse
        </Typography>
        <Button variant="outlined" sx={{ mt: 1.5 }} disabled={loading}>
          Choose file
        </Button>
        <input
          ref={inputRef}
          type="file"
          accept="application/pdf"
          hidden
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) void handleFile(file)
            e.target.value = ''
          }}
        />
      </Box>

      {error && (
        <Alert severity="error" sx={{ mt: 2 }}>
          {error}
        </Alert>
      )}
    </Box>
  )
}
